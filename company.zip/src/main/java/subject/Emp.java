package subject;

import java.sql.Date;

public class Emp {
	private int empno;
	private String ename;
	private String job;
	private Date hiredate;
	private int sal;
	private int dept_deptno;
	
	public Emp() {}

	public Emp(int empno, String ename, String job, Date hiredate, int sal, int dept_deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.hiredate = hiredate;
		this.sal = sal;
		this.dept_deptno = dept_deptno;
	} 
	
	
	public Emp(int empno, String ename, String job, int sal, int dept_deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.sal = sal;
		this.dept_deptno = dept_deptno;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Date getHiredate() {
		return hiredate;
	}

	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getDept_deptno() {
		return dept_deptno;
	}

	public void setDept_deptno(int dept_deptno) {
		this.dept_deptno = dept_deptno;
	}

	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", ename=" + ename + ", job=" + job + ", hiredate=" + hiredate + ", sal=" + sal
				+ ", dept_deptno=" + dept_deptno + "]";
	}
	
	
}
