package tryProject3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JdbcDeptDao implements DeptDao {

	private static JdbcDeptDao instance = null;
	
	public static JdbcDeptDao getInstance() {
		if (instance == null) {
			instance = new JdbcDeptDao();
		}
		
		return instance;
	}
	
	
	 @Override
	public List<Dept> allList() {
		 List<Dept> deptList = new ArrayList<>();
	        String query = "SELECT * FROM dept";

	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query);
	             ResultSet rs = pstmt.executeQuery()) {

	            while (rs.next()) {
	                Dept dept = new Dept();
	                dept.setDeptno(rs.getInt("deptno"));
	                dept.setDname(rs.getString("dname"));
	                dept.setLoc(rs.getString("loc"));
	                deptList.add(dept);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }	        
	        
	        return deptList;
	}

	@Override
	public int insertDept(Dept dept) {
		 int result = 0;
	        String query = "INSERT INTO dept (deptno, dname, loc) VALUES (?, ?, ?)";

	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {

	            pstmt.setInt(1, dept.getDeptno());
	            pstmt.setString(2, dept.getDname());
	            pstmt.setString(3, dept.getLoc());

	            result = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return result;
	}

	@Override
	public int updateDept(Dept dept) {
		  int result = 0;
	        String query = "UPDATE dept SET dname = ?, loc = ? WHERE deptno = ?";

	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {

	            pstmt.setString(1, dept.getDname());
	            pstmt.setString(2, dept.getLoc());
	            pstmt.setInt(3, dept.getDeptno());

	            result = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return result;
	}

	@Override
	public int deleteDept(int deptno) {
		  int result = 0;
	        String query = "DELETE FROM dept WHERE deptno = ?";

	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {

	            pstmt.setInt(1, deptno);
	            result = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return result;
	}

	@Override
	public Dept searchDept(int deptno) {
		  Dept dept = null;
	        String query = "SELECT * FROM dept WHERE deptno = ?";

	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {

	            pstmt.setInt(1, deptno);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                if (rs.next()) {
	                    dept = new Dept();
	                    dept.setDeptno(rs.getInt("deptno"));
	                    dept.setDname(rs.getString("dname"));
	                    dept.setLoc(rs.getString("loc"));
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return dept;
	}

}
