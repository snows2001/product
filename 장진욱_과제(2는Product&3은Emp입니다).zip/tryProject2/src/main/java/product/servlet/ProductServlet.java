package product.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product.JdbcProductDao;
import product.Product;

@WebServlet("/product/*")
public class ProductServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String parameter = uri.substring(lastIndex + 1);		
		
		String dispatchUrl = "";
		System.out.println(parameter);
		if (parameter.equals("input")) {
			dispatchUrl = "/input.jsp";
			
		} else if (parameter.equals("list")) {
			req.setAttribute("productList", JdbcProductDao.getInstance().productList());
			dispatchUrl = "/list.jsp";
			
		} else if (parameter.equals("inputResult")) {
			String name = req.getParameter("name");
			int price = Integer.parseInt(req.getParameter("price"));
			String kind = req.getParameter("kind");
			int result = JdbcProductDao.getInstance().
					insertProduct(new Product(name, price, kind));
			
			req.setAttribute("result", result);
			dispatchUrl = "product/list";
		} else if (parameter.equals("detail")) {
			int id = Integer.parseInt(req.getParameter("id"));
			req.setAttribute("product", JdbcProductDao.getInstance().findProduct(id));
			dispatchUrl = "/detail.jsp";			
		} else if (parameter.equals("update")) {
			Product toUpdateProduct = new Product(
					Integer.parseInt(req.getParameter("id")),
					req.getParameter("name"),
					Integer.parseInt(req.getParameter("price")),
					req.getParameter("kind"));
			req.setAttribute("updateResult", JdbcProductDao.getInstance().updateProduct(toUpdateProduct));
			dispatchUrl = "/product/detail";
		} else if (parameter.equals("remove")) {
			int id = Integer.parseInt(req.getParameter("id"));
			req.setAttribute("removeResult", JdbcProductDao.getInstance().deleteProduct(id));
			dispatchUrl = "product/list";
		}
	
		RequestDispatcher rd = req.getRequestDispatcher(dispatchUrl);
		rd.forward(req, resp);
	}


}
