package tryProject3.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tryProject3.Dept;
import tryProject3.Emp;
import tryProject3.JdbcDeptDao;
import tryProject3.JdbcEmpDao;


@WebServlet("/emp/*")
public class EmpServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		execute(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		execute(req, resp);
		
	}

	private void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("utf-8");
	    req.setCharacterEncoding("utf-8");

	    
		String uri = req.getRequestURI();
		System.out.println(uri);
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex + 1);		
		System.out.println(action);
		String dispatchUrl = null;	
		if (action.equals("list")) {
			if (req.getParameter("startDate") != null) {
				req.setAttribute("empList", JdbcEmpDao.getInstance().searchPeriodList(req.getParameter("startDate"), req.getParameter("endDate")));
			} else {
				req.setAttribute("empList", JdbcEmpDao.getInstance().allList());
			}
			
			dispatchUrl = "/list.jsp";
		} else if (action.equals("insert")) {
			req.setAttribute("deptList", JdbcDeptDao.getInstance().allList());
			dispatchUrl = "/insert.jsp";
			
		} else if (action.equals("add")) {
			Emp newEmp = new Emp( 
					req.getParameter("ename"), 
					req.getParameter("job"),
					Date.valueOf(req.getParameter("hiredate")), 
					Integer.parseInt(req.getParameter("sal")),
					new Dept(Integer.parseInt(req.getParameter("deptno"))));
			req.setAttribute("addResult", JdbcEmpDao.getInstance().insertEmp(newEmp));
			dispatchUrl = "emp/list";
			
		} else if (action.equals("detail")) {
			String empno = req.getParameter("empno");
			int empnoNum = Integer.parseInt(empno);
			req.setAttribute("empDetail", JdbcEmpDao.getInstance().displayEmp(new Emp(empnoNum)));			
			dispatchUrl = "/detail.jsp";
			
		} else if (action.equals("modify")) {	
			req.setAttribute("modifyEmpInfo", JdbcEmpDao.getInstance().displayEmp(new Emp(Integer.parseInt(req.getParameter("empno")))));
			req.setAttribute("deptList", JdbcDeptDao.getInstance().allList());
			dispatchUrl = "/modify.jsp";
			
		} else if (action.equals("update")) {			
			Emp toUpdateEmp = new Emp(Integer.parseInt(req.getParameter("empno")), 
					req.getParameter("ename"), 
					req.getParameter("job"),
					Date.valueOf(req.getParameter("hiredate")), 
					Integer.parseInt(req.getParameter("sal")),
					new Dept(Integer.parseInt(req.getParameter("deptno"))));
					
			req.setAttribute("updateResult", JdbcEmpDao.getInstance().updateEmp(toUpdateEmp));
			dispatchUrl = "emp/list";
		}
	
		RequestDispatcher dispatcher = req.getRequestDispatcher(dispatchUrl);
		dispatcher.forward(req, resp);
		
	}
	
	
}
