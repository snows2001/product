package project.emp;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import project.DataSource;
import project.dept.Department;

public class JdbcEmployeeDao implements EmployeeDao {

	@Override
	public void insert(Employee emp) {
		
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = 
					connection.prepareStatement("INSERT INTO EMP_PROJECT (ENAME,JOB ,HIREDATE,SAL,DEPTNO) VALUES (?,?,SYSDATE,?,?)");
			preparedStatement.setString(1, emp.getName());
			preparedStatement.setString(2, emp.getJob());
			preparedStatement.setInt(3, emp.getSalary());
			preparedStatement.setInt(4, emp.getDepartment().getId());
			preparedStatement.executeQuery();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Employee> findAll() {
		List<Employee> employees = new ArrayList<>();
		
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT e.*, TO_CHAR(e.hiredate, 'YYYY-MM-DD') AS hiredate FROM emp_project e ORDER BY e.empno DESC");
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Employee employee = new Employee();
				employee.setId(resultSet.getInt("empno"));
				employee.setHiredate(resultSet.getDate("hiredate"));
				employee.setJob(resultSet.getString("job"));
				employee.setName(resultSet.getString("ename"));
				employee.setSalary(resultSet.getInt("sal"));
				Department department = new Department();
				department.setId(resultSet.getInt("deptno"));
				employee.setDepartment(department);
				employees.add(employee);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return employees;
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		Employee employee = null;
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT e.*, TO_CHAR(e.hiredate, 'YYYY-MM-DD') AS hiredate FROM emp_project e WHERE empno = ?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				employee= new Employee();
				employee.setId(id);
				employee.setHiredate(resultSet.getDate("hiredate"));
				employee.setJob(resultSet.getString("job"));
				employee.setName(resultSet.getString("ename"));
				employee.setSalary(resultSet.getInt("sal"));
				Department department = new Department();
				department.setId(resultSet.getInt("deptno"));
				employee.setDepartment(department);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return employee;
	}

	@Override
	public void update(Employee emp) {
		// TODO Auto-generated method stub
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = 
					connection.prepareStatement("UPDATE EMP_PROJECT SET ENAME=?, JOB =? ,SAL=? ,DEPTNO=?  WHERE empno = ?");
			preparedStatement.setString(1, emp.getName());
			preparedStatement.setString(2, emp.getJob());
			preparedStatement.setInt(3, emp.getSalary());
			preparedStatement.setInt(4, emp.getDepartment().getId());
			preparedStatement.setInt(5, emp.getId());
			preparedStatement.executeQuery();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = 
					connection.prepareStatement("DELETE FROM emp_project where empno = ?");
			preparedStatement.setInt(1, id);
			preparedStatement.executeQuery();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Employee> findByDate(Date start, Date end) {
		List<Employee> employees = new ArrayList<>();
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM emp_project WHERE hiredate BETWEEN ? AND ?");
			preparedStatement.setDate(1, start);
			preparedStatement.setDate(2, end);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Employee employee= new Employee();
				employee.setId(resultSet.getInt("empno"));
				employee.setHiredate(resultSet.getDate("hiredate"));
				employee.setJob(resultSet.getString("job"));
				employee.setName(resultSet.getString("ename"));
				employee.setSalary(resultSet.getInt("sal"));
				Department department = new Department();
				department.setId(resultSet.getInt("deptno"));
				employee.setDepartment(department);
				employees.add(employee);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return employees;
	}
	

}
