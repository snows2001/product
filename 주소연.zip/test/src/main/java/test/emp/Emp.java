package test.emp;

import java.sql.Date;

public class Emp {
	private int empNo;
	private String empName;
	private String job;
	private Date hireDate;
	private int sal;
	private Dept dept;
	
	public Emp() {}
	
	public Emp(int empNo, String eName, Date hireDate) {
		this.empNo = empNo;
		this.empName = eName;
		this.hireDate = hireDate;
	}
	
	public Emp(int empNo, String eName, String job, Date hireDate, int sal, Dept dept) {
		this.empNo = empNo;
		this.empName = eName;
		this.job = job;
		this.hireDate = hireDate;
		this.sal = sal;
		this.dept = dept;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String eName) {
		this.empName = eName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", eName=" + empName + ", job=" + job + ", hireDate=" + hireDate + ", sal="
				+ sal + ", dept=" + dept + "]";
	}
}
