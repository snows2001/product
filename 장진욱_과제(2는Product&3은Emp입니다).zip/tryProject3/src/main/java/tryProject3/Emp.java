package tryProject3;

import java.sql.Date;

public class Emp {
	private int empno;
	private String ename;
	private String job;
	private Date hiredate;
	private int sal;
	private Dept dept;
	
	public Emp() {}
	
	public Emp(int empno) {
		this.empno = empno;
	}
	
	public Emp(int empno, String ename, String job, Date hiredate, int sal, Dept dept) {		
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.hiredate = hiredate;
		this.sal = sal;
		this.dept = dept;
	}
		
	
	public Emp(String parameter, String parameter2, Date valueOf, int parseInt, Dept dept2) {
		this.ename = parameter;
		this.job = parameter2;
		this.hiredate = valueOf;
		this.sal = parseInt;
		this.dept = dept2;
	}

	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Date getHiredate() {
		return hiredate;
	}
	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", ename=" + ename + ", job=" + job + ", hiredate=" + hiredate + ", sal=" + sal
				+ ", dept=" + dept + "]";
	}

	
	
}
