package subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcDeptDao implements DeptDao{

	@Override
	public boolean insert(Dept dept) {
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement(
				"INSERT INTO DEPT (DEPTNO, DNAME, LOC) VALUES (? , ? , ?)")) {

			pStatement.setInt(1, dept.getDeptno());
			pStatement.setString(2, dept.getDname());
			pStatement.setString(3, dept.getLoc());

			int affectedRows = pStatement.executeUpdate();

			if (affectedRows > 0) {
				System.out.println("성공");
			} else {
				System.out.println("실패");
}

		} catch (SQLException e) {
			e.printStackTrace();
}
		return false;
}

	@Override
	public List<Dept> findAll() {
		List<Dept> depts= new ArrayList<Dept>();
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement(
				 "SELECT * FROM DEPT");
				ResultSet rs = pStatement.executeQuery()) {
			
			while(rs.next()) {
				Dept dept= new Dept(
						rs.getInt("DEPTNO"),
						rs.getString("DNAME"),
						rs.getString("LOC"));
				depts.add(dept);
}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
}		
		  return depts;
}

	@Override
	public Dept findById(int deptno) {
		 try (Connection connection = DataSource.getDataSource();
	             PreparedStatement pStatement = connection.prepareStatement(
	            		 "SELECT * FROM DEPT WHERE DEPTNO = ?");
				) {
			 pStatement.setInt(1, deptno);
			 ResultSet rs = pStatement.executeQuery();
			 
		 if (rs.next()) {
			Dept dept = new Dept(
					rs.getInt("DEPTNO"),
					rs.getString("DNAME"),
					rs.getString("LOC"));
				return dept;
}
			 
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
}				
		   return null;
}

	@Override
	public boolean update(Dept dept) {
		 try (Connection conn = DataSource.getDataSource();
			       PreparedStatement pStatement = conn.prepareStatement(
			    	  "UPDATE DEPT SET DNAME = ?, LOC = ? WHERE DEPTNO = ?"))
			        {
			          pStatement.setString(1, dept.getDname());
			          pStatement.setString(2, dept.getLoc());
			          pStatement.setInt(3, dept.getDeptno());
			          
			          pStatement.executeUpdate();
}
			        catch (Exception e)
			        {
			            e.printStackTrace();
}
			        return false;
}
	@Override
	public boolean deleteById(int deptno) {
		 try (Connection conn = DataSource.getDataSource();
	          PreparedStatement pStatement = conn.prepareStatement(
	          "DELETE FROM DEPT WHERE DEPTNO = ?"))
	        {
	            pStatement.setInt(1, deptno);
	            
	            pStatement.executeUpdate();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
}


	        return false;
}
}
