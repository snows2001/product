package project.dept;

import java.util.List;

public interface DepartmentDao {
	void insert(Department dept);
	List<Department> findAll();

}
