package subject;

import java.util.List;


public interface EmpDao {

		boolean insert(Emp emp);
		List<Emp> findAll();
		Emp findById(int empno);
		boolean update(Emp emp);
		boolean deleteById(int empno);						
	}