package project;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateChanger {
	
	public static Date inputDate(String inputDate) {
		Date sqlDate = null;
	
		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try {
            LocalDate date = LocalDate.parse(inputDate, inputFormatter);
            sqlDate = Date.valueOf(date);
     
        } catch (DateTimeParseException e) {
            String error = "Invalid Date Format";
        }
		
		return sqlDate;
    }

}
