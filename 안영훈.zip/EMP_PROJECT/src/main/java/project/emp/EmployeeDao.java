package project.emp;

import java.sql.Date;
import java.util.List;

public interface EmployeeDao {
	
	void insert(Employee emp);
	List<Employee> findAll();
	Employee findById(int id);
	void update(Employee emp);
	void delete(int id);
	List<Employee> findByDate(Date start, Date end);
	

}
