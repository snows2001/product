package test.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/emp/*")
public class EmpServlet extends HttpServlet {
	private JDBCEmpDAO empDao = new JDBCEmpDAO();
	private JDBCDeptDAO deptDao = new JDBCDeptDAO();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		getProcess(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		postProcess(req, resp);
	}
	
	private void getProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		int lastIdx = uri.lastIndexOf("/");
		String action = uri.substring(lastIdx + 1);
		String dispatcherUrl = null;

		if (action.equals("input")) {
			List<Dept> depts = deptDao.selectAll();
			req.setAttribute("depts", depts);
			dispatcherUrl = "/input.jsp";
		} else if (action.equals("list")) {
			List<Emp> list = empDao.selectAll();
			req.setAttribute("emps", list);
			dispatcherUrl = "/list.jsp";
		} else if (action.equals("detail")) {
			Emp emp = empDao.selectById(Integer.parseInt(req.getParameter("empNo")));
			List<Dept> depts = deptDao.selectAll();
			req.setAttribute("emp", emp);
			req.setAttribute("depts", depts);
			if (emp != null)
				req.setAttribute("empDept", emp.getDept().getDeptNo());
			dispatcherUrl = "/detail.jsp";
		} else if (action.equals("search")) {
			List<Emp> list = empDao.selectByDate(Date.valueOf(req.getParameter("start")), Date.valueOf(req.getParameter("end")));
			req.setAttribute("emps", list);
			dispatcherUrl = "/list.jsp";
		}
		
		RequestDispatcher rd = req.getRequestDispatcher(dispatcherUrl);
		rd.forward(req, resp);
	}
	
	private void postProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		
		String uri = req.getRequestURI();
		int lastIdx = uri.lastIndexOf("/");
		String action = uri.substring(lastIdx + 1);
		
		String alertText = "";
		String href = "";
		
		if (action.equals("save")) {
			Emp emp = new Emp(0, req.getParameter("eName"), req.getParameter("job"), null, Integer.parseInt(req.getParameter("sal")), new Dept(Integer.parseInt(req.getParameter("dept"))));
			if (empDao.insert(emp)) {
				alertText = "등록 완료";
				href = "/test/emp/input";
			}
		} else if (action.equals("update")) {
			Emp emp = new Emp(Integer.parseInt(req.getParameter("empNo")), req.getParameter("empName"), req.getParameter("job"), null, Integer.parseInt(req.getParameter("sal")), new Dept(Integer.parseInt(req.getParameter("dept"))));
			if (empDao.update(emp)) {
				alertText = "수정 완료";
				href = "/test/emp/list";
			}
		} else if (action.equals("delete")) {
			if (empDao.deleteById(Integer.parseInt(req.getParameter("empNo")))) {
				alertText = "삭제 완료";
				href = "/test/emp/list";
			}
		}

		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter writer = resp.getWriter();
		writer.println("<script>alert('" + alertText + "'); location.href='" + href +"';</script>"); 
		writer.close();
	}
}
