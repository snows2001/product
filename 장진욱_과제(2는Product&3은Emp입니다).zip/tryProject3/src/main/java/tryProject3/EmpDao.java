package tryProject3;

import java.util.List;

public interface EmpDao {
	public List<Emp> allList();
	public int insertEmp(Emp emp);
	public int updateEmp(Emp emp);
	public int deleteEmp(int empno);
	public Emp displayEmp(Emp emp); // 번호혹은이름검색
}
