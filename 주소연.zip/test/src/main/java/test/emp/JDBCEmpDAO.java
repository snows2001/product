package test.emp;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JDBCEmpDAO {
	public List<Emp> selectAll() {
		List<Emp> result = null;
		
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("SELECT EMPNO, ENAME, HIREDATE FROM EMP ORDER BY EMPNO DESC");
				ResultSet queryResult = pStatement.executeQuery();) {
			
			result = new ArrayList<Emp>();
			while (queryResult.next())
				result.add(new Emp(queryResult.getInt("EMPNO"), queryResult.getString("ENAME"), queryResult.getDate("HIREDATE")));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public Emp selectById(int id) {
		Emp result = null;
		
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM EMP WHERE EMPNO = ?")) {
			
			pStatement.setInt(1, id);
			ResultSet queryResult = pStatement.executeQuery();
			
			if (queryResult.next())
				result = new Emp(queryResult.getInt("EMPNO"), queryResult.getString("ENAME"), queryResult.getString("JOB"), queryResult.getDate("HIREDATE"), queryResult.getInt("SAL"), new Dept(queryResult.getInt("DEPTNO")));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public List<Emp> selectByDate(Date start, Date end) {
		List<Emp> result = null;
		
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("SELECT EMPNO, ENAME, HIREDATE FROM EMP WHERE HIREDATE BETWEEN ? AND ? ORDER BY EMPNO DESC")) {
			
			pStatement.setDate(1, start);
			pStatement.setDate(2, end);
			ResultSet queryResult = pStatement.executeQuery();
			
			result = new ArrayList<Emp>();
			while (queryResult.next())
				result.add(new Emp(queryResult.getInt("EMPNO"), queryResult.getString("ENAME"), queryResult.getDate("HIREDATE")));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public boolean insert(Emp emp) {
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("INSERT INTO EMP (ENAME, JOB, SAL, DEPTNO) VALUES (?, ?, ?, ?)")) {
			
			pStatement.setString(1, emp.getEmpName());
			pStatement.setString(2, emp.getJob());
			pStatement.setInt(3, emp.getSal());
			pStatement.setInt(4, emp.getDept().getDeptNo());
			
			if (pStatement.executeUpdate() > 0)
				return true ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false ;
	}
	
	public boolean update(Emp emp) {
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("UPDATE EMP SET ENAME = ?, JOB = ?, SAL = ?, DEPTNO = ? WHERE EMPNO = ?")) {
			
			pStatement.setString(1, emp.getEmpName());
			pStatement.setString(2, emp.getJob());				
			pStatement.setInt(3, emp.getSal());
			pStatement.setInt(4, emp.getDept().getDeptNo());
			pStatement.setInt(5, emp.getEmpNo());
			
			if (pStatement.executeUpdate() > 0)
				return true ;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false ;
	}

	
	public boolean deleteById(int id) {
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("DELETE FROM EMP WHERE EMPNO = ?")) {
			
			pStatement.setInt(1, id);
			if (pStatement.executeUpdate() > 0)
				return true ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false ;
	}
}
