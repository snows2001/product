package subject;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/emp/*")
public class EmpServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	private void process(HttpServletRequest req, HttpServletResponse resp) {
		String uri = req.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex + 1);
		System.out.println(action);
		
		if(action.equals("input")) {
			
		} else if (action.equals("save")) {
			EmpDao empDao = new JdbcEmpDao();
			Emp emp = new Emp(Integer.parseInt(req.getParameter("empno")),req.getParameter("ename"),req.getParameter("job"),
							  Integer.parseInt(req.getParameter("sal"))
							 ,Integer.parseInt(req.getParameter("dept_deptno")));
			empDao.insert(emp);
		} else if (action.equals("findAll")) {
			EmpDao empDao = new JdbcEmpDao();
			List<Emp> emps = empDao.findAll();
			req.setAttribute("emps", emps);
		} else if(action.equals("findEmp")) {
			EmpDao empDao = new JdbcEmpDao();
			Emp emp = empDao.findById(Integer.parseInt(req.getParameter("empno")));
			req.setAttribute("emp", emp);
		} else if (action.equals("update")) {
			EmpDao empDao = new JdbcEmpDao();
			Emp emp = new Emp(Integer.parseInt(req.getParameter("empno")),req.getParameter("ename"),req.getParameter("job"),
					  Integer.parseInt(req.getParameter("sal"))
					 ,Integer.parseInt(req.getParameter("dept_deptno")));
			empDao.update(emp);
		} else if (action.equals("delete")) {
			EmpDao empDao = new JdbcEmpDao();
			empDao.deleteById(Integer.parseInt(req.getParameter("empno")));
		}
		
		String dispatcherUrl = null;
		
		if (action.equals("input")) {
			dispatcherUrl = "/input.html";
		} else if (action.equals("save")) {
			dispatcherUrl = "/.jsp";
		} else if (action.equals("findAll")) {
			dispatcherUrl = "/result.jsp";
		} else if (action.equals("findEmp")) {
			dispatcherUrl = "/";
		} else if (action.equals("update")) {
			dispatcherUrl = "/";
		} else if (action.equals("delete")) {
			dispatcherUrl = "/";
		}
	}
}
