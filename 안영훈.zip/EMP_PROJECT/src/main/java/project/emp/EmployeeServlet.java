package project.emp;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.DateChanger;
import project.dept.Department;
import project.dept.JdbcDepartmentDao;

@WebServlet("/emp/*")
public class EmployeeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(req,resp);
	}

	protected void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex + 1);
		
		if(action.equals("main")) {
			JdbcDepartmentDao jdbcDepartmentDao = new JdbcDepartmentDao();
			List<Department> departments = jdbcDepartmentDao.findAll();
			req.setAttribute("departments", departments);
		}else if(action.equals("register")) {
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			Employee emp = new Employee();
			Department department = new Department();
			department.setId(Integer.parseInt(req.getParameter("deptno")));
			emp.setName(req.getParameter("ename"));
			emp.setJob(req.getParameter("job"));
			emp.setSalary(Integer.parseInt(req.getParameter("sal")));
			emp.setDepartment(department);
			jdbcEmployeeDao.insert(emp);
//			System.out.println(department);
//			System.out.println(emp);
		}else if(action.equals("findall")) {
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			List<Employee> employees = jdbcEmployeeDao.findAll();
			req.setAttribute("employees", employees);
		}else if(action.equals("detail")) {
			JdbcDepartmentDao jdbcDepartmentDao = new JdbcDepartmentDao();
			List<Department> departments = jdbcDepartmentDao.findAll();
			req.setAttribute("departments", departments);
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			Employee employee = jdbcEmployeeDao.findById(Integer.parseInt(req.getParameter("id")));
			req.setAttribute("employee", employee);
			
		}else if(action.equals("revise")) {
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			Employee emp = new Employee();
			emp.setId(Integer.parseInt(req.getParameter("id")));
			emp.setName(req.getParameter("name"));
			emp.setJob(req.getParameter("job"));
			emp.setSalary(Integer.parseInt(req.getParameter("sal")));
			Department dept = new Department();
			dept.setId(Integer.parseInt(req.getParameter("deptno")));
			emp.setDepartment(dept);
			jdbcEmployeeDao.update(emp);
			
		}else if(action.equals("delete")) {
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			jdbcEmployeeDao.delete(Integer.parseInt(req.getParameter("id")));
			
		}else if(action.equals("findbydate")) {
			JdbcEmployeeDao jdbcEmployeeDao = new JdbcEmployeeDao();
			Date startDate = DateChanger.inputDate(req.getParameter("startDate"));
			Date endDate = DateChanger.inputDate(req.getParameter("endDate"));
			List<Employee> employees = jdbcEmployeeDao.findByDate(startDate, endDate);
			req.setAttribute("employees", employees);
		}
		
		String dispatchUrl = null;
		
		if(action.equals("main")) {
			dispatchUrl = "/register.jsp";
		}else if(action.equals("register")) {
			resp.sendRedirect(req.getContextPath()+"/emp/main");
//			dispatchUrl= "/complete.jsp";
		}else if(action.equals("findall")) {
			dispatchUrl = "/employeeAll.jsp"; 
		}else if(action.equals("backtomain")) {
			resp.sendRedirect(req.getContextPath()+"/emp/main");
		}else if(action.equals("detail")) {
			dispatchUrl="/detail.jsp";
		}else if(action.equals("revise")) {
			resp.sendRedirect(req.getContextPath()+"/emp/findall");
		}else if(action.equals("delete")) {
			resp.sendRedirect(req.getContextPath()+"/emp/findall");
		}else if(action.equals("backtolist")) {
			resp.sendRedirect(req.getContextPath()+"/emp/findall");
		}else if(action.equals("findbydate")) {
			dispatchUrl="/employeeAll.jsp";
		}
		if(dispatchUrl != null) {
			RequestDispatcher rd = req.getRequestDispatcher(dispatchUrl);
			rd.forward(req,resp);
		}
	}
	
	
	
}
