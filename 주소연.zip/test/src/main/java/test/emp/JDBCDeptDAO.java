package test.emp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JDBCDeptDAO {
	public List<Dept> selectAll() {
		List<Dept> result = null;
		
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM DEPT ORDER BY DNAME");
				ResultSet queryResult = pStatement.executeQuery();) {
			
			result = new ArrayList<Dept>();
			while (queryResult.next())
				result.add(new Dept(queryResult.getInt("DEPTNO"), queryResult.getString("DNAME"), queryResult.getString("LOC")));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
}
