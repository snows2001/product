package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcProductDao implements ProductDao{

	private static JdbcProductDao instance = null;
	
	public static JdbcProductDao getInstance() {
		if (instance == null)
			instance = new JdbcProductDao();
		
		return instance;		
	}	
	
	@Override
	public List<Product> productList() {
		List<Product> products = new ArrayList<Product>();		
		try (Connection connection = DataSource.getDataSource();
			PreparedStatement preStatement = connection.prepareStatement(
				"SELECT * FROM PRODUCT");
				ResultSet rs = preStatement.executeQuery()) {
			
			while(rs.next()) { // pk만 if이며, 나머지는 whlie로 데이터 검색
					Product product = new Product(rs.getInt("id"), 
					rs.getString("name"), 
					rs.getInt("price"), 
					rs.getString("kind"));
					products.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}			
		return products;
	}

	@Override
	public int insertProduct(Product product) {
		int result = 0;				
		try (Connection connection = DataSource.getDataSource();
			PreparedStatement pstmt 
			  = connection.prepareStatement("INSERT INTO PRODUCT (NAME, PRICE, KIND)"
			  		+ " VALUES (?, ?, ?)")){ //줄이 긴 경우 엔터치면 띄어쓰기 가능 / V 앞에 띄어쓰기 필요			
			
			pstmt.setString(1, product.getName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getKind());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e){
			e.printStackTrace();
        } 
		
		return result;		
	}

	@Override
	public int updateProduct(Product product) {
		int result = 0;
		String sql = "UPDATE PRODUCT SET NAME = ?, PRICE = ?, KIND = ?"
				+ " WHERE ID = ?";
		
		try {
			
			Connection conn = DataSource.getDataSource();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getKind());
			pstmt.setInt(4, product.getId());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public int deleteProduct(int id) {
		  int result = 0;

	      try (Connection conn = DataSource.getDataSource();
	            PreparedStatement pStatement = conn.prepareStatement("delete from product where id = ?")) {
	    	  
	    	  pStatement.setInt(1, id);
	    	  result = pStatement.executeUpdate();	    	  
	    	  
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.out.println("변경 실패!");
	         
	      }

	      return result;
	   }	

	@Override
	public Product findProduct(int id) {
		Product product = null;		
		String sql = "SELECT * FROM PRODUCT WHERE ID = ?";
		
		try {
			Connection conn = DataSource.getDataSource();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				product = new Product(id, rs.getString("name"), rs.getInt("price"), rs.getString("kind"));
			}	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return product;
	}
}
