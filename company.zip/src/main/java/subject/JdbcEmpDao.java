package subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcEmpDao implements EmpDao{

	@Override
	public boolean insert(Emp emp) {
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement(
				"INSERT INTO EMP (EMPNO, ENAME, JOB, HIREDATE, SAL, DEPT_DEPTNO) VALUES (?,?,?,SYSDATE,?,?)")) {

			pStatement.setInt(1, emp.getEmpno());
			pStatement.setString(2, emp.getEname());
			pStatement.setString(3, emp.getJob());
			pStatement.setInt(4, emp.getSal());
			pStatement.setInt(5, emp.getDept_deptno());
	
			int affectedRows = pStatement.executeUpdate();

			if (affectedRows > 0) {
				System.out.println("성공");
			} else {
				System.out.println("실패");
}

		} catch (SQLException e) {
			e.printStackTrace();
}
		return false;
}

	@Override
	public List<Emp> findAll() {
		List<Emp> emps= new ArrayList<Emp>();
		try (Connection connection = DataSource.getDataSource();
				PreparedStatement pStatement = connection.prepareStatement(
				"SELECT * FROM EMP");
				ResultSet rs = pStatement.executeQuery()) {
			
			while(rs.next()) {
				Emp emp= new Emp(
						rs.getInt("EMPNO"),
						rs.getString("ENAME"),
						rs.getString("JOB"),
						rs.getDate("HIREDATE"),
						rs.getInt("SAL"),
						rs.getInt("DEPT_DEPTNO"));
						emps.add(emp);
}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
}		
		  return emps;
}

	@Override
	public Emp findById(int empno) {
		 try (Connection connection = DataSource.getDataSource();
	             PreparedStatement pStatement = connection.prepareStatement(
	            		 "SELECT * FROM EMP WHERE EMPNO = ?");
				) {
			 pStatement.setInt(1, empno);
			 ResultSet rs = pStatement.executeQuery();
			 
		 if (rs.next()) {
			Emp emp = new Emp(
					rs.getInt("EMPNO"),
					rs.getString("ENAME"),
					rs.getString("JOB"),
					rs.getDate("HIREDATE"),
					rs.getInt("SAL"),
					rs.getInt("DEPT_DEPTNO"));
				return emp;
}
			 
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
}				
		   return null;
}

	@Override
	public boolean update(Emp emp) {
		 try (Connection conn = DataSource.getDataSource();
			       PreparedStatement pStatement = conn.prepareStatement(
			    	  "UPDATE EMP SET ENAME = ?, JOB = ?, HIREDATE = ?, SAL = ?, DEPT_DEPTNO = ? WHERE EMPNO = ?"))
			        {
			          pStatement.setString(1, emp.getEname());
			          pStatement.setString(2, emp.getJob());
			          pStatement.setDate(3, emp.getHiredate());
			          pStatement.setInt(4, emp.getSal());
			          pStatement.setInt(5, emp.getDept_deptno());
			          pStatement.setInt(6, emp.getEmpno());
			          
			          pStatement.executeUpdate();
}
			        catch (Exception e)
			        {
			            e.printStackTrace();
}
			        return false;
}

	@Override
	public boolean deleteById(int empno) {
		try (Connection conn = DataSource.getDataSource();
		          PreparedStatement pStatement = conn.prepareStatement(
		          "DELETE FROM EMP WHERE EMPNO = ?"))
		        {
		            pStatement.setInt(1, empno);
		            
		            pStatement.executeUpdate();
		        }   catch (Exception e)
		        {
		            e.printStackTrace();
}
				    return false;
}
}
