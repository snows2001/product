package product;

import java.util.List;

public interface ProductDao {
	
	public List<Product> productList();
	public int insertProduct(Product product);
	public int updateProduct(Product product);
	public int deleteProduct(int id);
	public Product findProduct(int id);
}
