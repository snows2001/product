package tryProject3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class JdbcEmpDao implements EmpDao{

	private static JdbcEmpDao instance = null;
	
	public static JdbcEmpDao getInstance() {
		if (instance == null) {			
			instance = new JdbcEmpDao();
		}
		
		return instance;
	}
	
	
	@Override
	public List<Emp> allList() {
		List<Emp> empList = new ArrayList<>();
        String query = "SELECT * FROM emp";
        
        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Emp emp = new Emp();
                emp.setEmpno(rs.getInt("empno"));
                emp.setEname(rs.getString("ename"));
                emp.setJob(rs.getString("job"));                
                emp.setHiredate(rs.getDate("hiredate"));
                emp.setSal(rs.getInt("sal"));                
                emp.setDept(new Dept(rs.getInt("deptno")));                
                empList.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return empList;
	}

	@Override
	public int insertEmp(Emp emp) {
		 int result = 0;
	        String query = "INSERT INTO emp (ename, job, hiredate, sal,deptno) "
	        		+ "VALUES (?, ?, ?, ?, ?)";
	        
	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            
	            pstmt.setString(1, emp.getEname());
	            pstmt.setString(2, emp.getJob());	            
	            pstmt.setDate(3, emp.getHiredate());
	            pstmt.setInt(4, emp.getSal());	            
	            pstmt.setInt(5, emp.getDept().getDeptno());	            
	            result = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return result;
	}

	@Override
	public int updateEmp(Emp emp) {
		int result = 0;
        String query = "UPDATE emp SET ename = ?, job = ?, hiredate = ?, sal = ?, deptno = ? WHERE empno = ?";
        
        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, emp.getEname());
            pstmt.setString(2, emp.getJob());            
            pstmt.setDate(3, emp.getHiredate());
            pstmt.setInt(4, emp.getSal());            
            pstmt.setInt(5, emp.getDept().getDeptno());
            pstmt.setInt(6, emp.getEmpno());
            
            result = pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return result;
	}

	@Override
	public int deleteEmp(int empno) {
		 int result = 0;
	        String query = "DELETE FROM emp WHERE empno = ?";
	        
	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setInt(1, empno);
	            result = pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return result;		
	}

	@Override
	public Emp displayEmp(Emp emp) {
		  Emp resultEmp = null;
	        String query = "SELECT * FROM emp WHERE empno = ?";
	        
	        try (Connection conn = DataSource.getDataSource();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setInt(1, emp.getEmpno());
	            try (ResultSet rs = pstmt.executeQuery()) {
	                if (rs.next()) {
	                    resultEmp = new Emp();
	                    resultEmp.setEmpno(rs.getInt("empno"));
	                    resultEmp.setEname(rs.getString("ename"));
	                    resultEmp.setJob(rs.getString("job"));                
	                    resultEmp.setHiredate(rs.getDate("hiredate"));
	                    resultEmp.setSal(rs.getInt("sal"));                
	                    resultEmp.setDept(new Dept(rs.getInt("deptno")));  
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return resultEmp;
	}


	public List<Emp> searchPeriodList(String startDate, String endDate) {
		List<Emp> searchList = new ArrayList<>();
		String query = "SELECT * FROM emp where hiredate between ? and ?";
        
        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pstmt = conn.prepareStatement(query)){
            
        	pstmt.setString(1, startDate);
    		pstmt.setString(2, endDate);
    		ResultSet rs = pstmt.executeQuery();
    		
            while (rs.next()) {
                Emp emp = new Emp();
                emp.setEmpno(rs.getInt("empno"));
                emp.setEname(rs.getString("ename"));
                emp.setJob(rs.getString("job"));                
                emp.setHiredate(rs.getDate("hiredate"));
                emp.setSal(rs.getInt("sal"));                
                emp.setDept(new Dept(rs.getInt("deptno")));                
                searchList.add(emp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
           
		
		Collections.sort(searchList, new Comparator<Emp>() {
			@Override
			public int compare(Emp o1, Emp o2) {
				return o2.getEmpno() - o1.getEmpno();
			}			
		});
        
        return searchList;
		
		
	}

}
