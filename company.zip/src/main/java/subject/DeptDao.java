package subject;

import java.util.List;

public interface DeptDao {
	
	boolean insert(Dept dept);
	List<Dept> findAll();
	Dept findById(int deptno);
	boolean update(Dept dept);
	boolean deleteById(int deptno);	
}
