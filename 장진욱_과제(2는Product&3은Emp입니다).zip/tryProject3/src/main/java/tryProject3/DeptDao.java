package tryProject3;

import java.util.List;

public interface DeptDao {
	public List<Dept> allList();
	public int insertDept(Dept dept);
	public int updateDept(Dept dept);
	public int deleteDept(int deptno);
	public Dept searchDept(int deptno);
}
