package project.dept;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import project.DataSource;

public class JdbcDepartmentDao implements DepartmentDao {

	@Override
	public void insert(Department dept) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Department> findAll() {
		// TODO Auto-generated method stub
		List<Department> departments = new ArrayList<>();
		try(Connection connection = DataSource.getDataSource()){
			PreparedStatement preparedStatement = connection.prepareStatement("Select * FROM DEPT_PROJECT");
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Department department = new Department();
				department.setId(resultSet.getInt("deptno"));
				department.setName(resultSet.getString("dname"));
				department.setLocation(resultSet.getString("loc"));
				departments.add(department);
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return departments;
	}
	

}
